import React from 'react';

const NoMatch = () => {
    return (
        <div>
            <h3>Route not found.</h3>
        </div>
    );
};

export default NoMatch;