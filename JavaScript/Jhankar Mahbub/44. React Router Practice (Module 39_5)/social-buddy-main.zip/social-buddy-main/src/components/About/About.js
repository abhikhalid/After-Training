import React from 'react';

const About = () => {
    return (
        <div>
            <h3>This is about component</h3>
        </div>
    );
};

export default About;